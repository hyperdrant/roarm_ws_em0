import os
import cv2

import rclpy
from rclpy.node import Node

from face_tracker_msgs.msg import Offset


class FaceTrackerNode(Node):
    def __init__(self):
        super().__init__('face_tracker_node')

        # ROS 参数：摄像头 index、是否显示画面、死区
        self.declare_parameter('camera_index', 2)
        self.declare_parameter('show_view', True)
        self.declare_parameter('dead_zone', 0.1)

        cam_idx = int(self.get_parameter('camera_index').value)
        self.show_view = bool(self.get_parameter('show_view').value)
        self.dead_zone = float(self.get_parameter('dead_zone').value)

        # 打开摄像头
        self.cap = cv2.VideoCapture(cam_idx)
        if not self.cap.isOpened():
            raise RuntimeError(f"Camera open failed. Try another index. Current: {cam_idx}")

        # 加载 OpenCV 自带 Haar 模型
        # 加载 Haar 模型（兼容没有 cv2.data 的 OpenCV 构建）
        cascade_file = "haarcascade_frontalface_default.xml"

        candidates = []

        # 1) 有些 OpenCV 才有 cv2.data.haarcascades
        if hasattr(cv2, "data") and hasattr(cv2.data, "haarcascades"):
            candidates.append(os.path.join(cv2.data.haarcascades, cascade_file))

        # 2) Ubuntu/Debian 常见路径
        candidates += [
            os.path.join("/usr/share/opencv4/haarcascades", cascade_file),
            os.path.join("/usr/share/opencv/haarcascades", cascade_file),
        ]

        cascade_path = None
        for p in candidates:
            if p and os.path.exists(p):
                cascade_path = p
                break

        if cascade_path is None:
            raise RuntimeError(
                "Cannot find Haar cascade file. Tried:\n" + "\n".join([str(x) for x in candidates])
            )

        self.get_logger().info(f"Using cascade: {cascade_path}")
        self.face_cascade = cv2.CascadeClassifier(cascade_path)
        if self.face_cascade.empty():
            raise RuntimeError(f"Failed to load Haar cascade from: {cascade_path}")


        # 发布器
        self.pub = self.create_publisher(Offset, '/target/offset', 10)

        # 定时器：大约 30Hz（你也可以改成 0.05=20Hz）
        self.timer = self.create_timer(1.0 / 30.0, self.loop)

        self.get_logger().info(
            f"FaceTrackerNode started. camera_index={cam_idx}, show_view={self.show_view}, dead_zone={self.dead_zone}"
        )

    def loop(self):
        ret, frame = self.cap.read()
        if not ret:
            self.get_logger().warn("Frame read failed.")
            return

        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        faces = self.face_cascade.detectMultiScale(
            gray,
            scaleFactor=1.1,
            minNeighbors=5,
            minSize=(60, 60)
        )

        h, w = frame.shape[:2]
        img_cx, img_cy = w // 2, h // 2

        # 默认发布无效
        msg = Offset()
        msg.ux = 0.0
        msg.uy = 0.0
        msg.valid = False

        if len(faces) > 0:
            # 选最大脸
            x, y, fw, fh = max(faces, key=lambda b: b[2] * b[3])
            cx, cy = x + fw // 2, y + fh // 2

            # 计算归一化偏移
            ux = (cx - img_cx) / (w / 2)
            uy = (cy - img_cy) / (h / 2)

            # 死区防抖
            if abs(ux) < self.dead_zone:
                ux = 0.0
            if abs(uy) < self.dead_zone:
                uy = 0.0

            msg.ux = float(ux)
            msg.uy = float(uy)
            msg.valid = True

            if self.show_view:
                cv2.drawMarker(frame, (img_cx, img_cy), (0, 255, 0),
                               markerType=cv2.MARKER_CROSS, thickness=2)
                cv2.rectangle(frame, (x, y), (x + fw, y + fh), (255, 0, 0), 2)
                cv2.circle(frame, (cx, cy), 5, (0, 0, 255), -1)
                cv2.putText(frame, f"ux={ux:.2f}, uy={uy:.2f}", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
        else:
            if self.show_view:
                cv2.drawMarker(frame, (img_cx, img_cy), (0, 255, 0),
                               markerType=cv2.MARKER_CROSS, thickness=2)
                cv2.putText(frame, "No face", (10, 30),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

        # 发布
        self.pub.publish(msg)

        # 可视化
        if self.show_view:
            cv2.imshow("Face Tracker (ROS2)", frame)
            key = cv2.waitKey(1) & 0xFF
            if key == 27:  # ESC
                self.get_logger().info("ESC pressed. Shutting down.")
                rclpy.shutdown()

    def destroy_node(self):
        if hasattr(self, 'cap') and self.cap is not None:
            self.cap.release()
        try:
            cv2.destroyAllWindows()
        except Exception:
            pass
        super().destroy_node()


def main():
    rclpy.init()
    node = FaceTrackerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
